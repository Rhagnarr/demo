<?php
	include('header.php');
?>

<body>
	<div class="cadre_1">
		<div class="img_user">
			
				<img src='images/nous/Pialla.jpg' width=150px height="150px" alt="Photo Gautier Pialla"/>

				<p class="nom">Gautier Pialla</p>
			
		</div>	
	</div>

	<div class="cadre_1">
		<div class="img_user">
			
				<img src='images/nous/Hassan.jpg' width=150px height="150px" alt="Photo Hassan Eddery"/>

				<p class="nom">Hassan Eddery</p>
			
		</div>
		<div class="img_user">
			
				<img src='images/nous/GauthierM.jpg' width=150px height="150px" alt="Photo Gauthier Masini"/>

				<p class="nom">Gauthier Masini</p>
			
		</div>
	</div>

	<div class="cadre_1">
		<div class="img_user">
			
				<img src='images/nous/Jef.jpg' width=150px height="150px" alt="Photo Jeffrey Mbadinga"/>

				<p class="nom">Jeffrey Mbadinga</p>
			
		</div>
			
	</div>

	<div class="cadre_1">
		<div class="img_user">
			
				<img src='images/nous/Gaetan.jpg' width=150px height="150px" alt="Nom Gaetan Boulogne"/>

				<p class="nom">Gaetan Boulogne</p>
			
		</div>
		<div class="img_user">
			
				<img src='images/nous/Saad.jpg' width=150px height="150px" alt="Photo Saad Bendaoud"/>

				<p class="nom">Saad Bendaoud</p>
			
		</div>
			
	</div>

	<div class="cadre_1">
		<div class="img_user">
			
				<img src="https://i.pinimg.com/originals/3b/21/64/3b216486dde36a86ed6c8b77c955b383.jpg" width=150px height="150px" alt=""/>

				<p class="nom">Antonin</p>
			
		</div>	
	</div>
</body>

<?php
	include('footer.php');
?>
