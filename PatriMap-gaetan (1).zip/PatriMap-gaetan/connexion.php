<?php
include('header.php');

$redirect = false;

if(isset($_POST['Connexion'])){
    // si le bouton Connexion a été cliqué alors
    if(empty($_POST['mail'])){
        $errormessage .= "<p>Le mail n'a pas été donné !</p>";
    }
    else {

        $mail = $_POST['mail'];
        if(empty($_POST['mdp'])){
            $errormessage .= "<p>Le mot de passe n'a pas été donné !</p>";
        }
        else {

            $mdp = $_POST['mdp'];

            $stmt = $bdd->prepare("SELECT * FROM Utilisateur WHERE Email = :Email");
            $stmt->bindParam(':Email', $mail);
            $stmt->execute();

            if($stmt->rowCount() == 1)
            {

                $row = $stmt->fetch();

                if ($row['Email']==$mail){

                    $grain = 'b54sFmjJ52';
                    $sel = 'a12Gfd51gzR';
                    $sha1 = sha1($grain.$mdp.$sel);

                    if($sha1 == $row['Password']) {

                        $_SESSION['login'] = $row['Prenom'];
                        $_SESSION['id'] = $row['Id'];
                        $redirect = true;

                    }
                    else {
                        $errormessage .= '<p>Le mot de passe est incorrect !</p>';
                    }
                }
                else {
                    $errormessage .= '<p>Combinaison mot de passe / identifiant inconnue !</p>';
                }

            }
            else{
                $errormessage .= '<p>Email inconnu !</p>';
            }
        }
    }
}

if(isset($errormessage)){

    ?>
    <div class="div_msg div_msg_error">
        <p><b>Une ou plusieurs erreurs sont survenues !</b></p>
        <?php echo $errormessage ?>
    </div>
    <?php
}

if($redirect){
    echo "<script type='text/javascript'>document.location.replace('index.php');</script>";
}
?>
	<h2 class="connx">Connexion</h2>
    </br>
	<form method="post" class="formul" action="connexion.php" >
		<p>
			<label class="Text" for="mail">Mail : </label>
			<input class="Text" type="email" name="mail" placeholder="Votre mail"  />		
			<br/>
		</p>
		<p>
			<label class="Text" for="mdp">Mot de passe :</label>
			<input class="Text" type ="password" name="mdp" placeholder="Votre mot de passe"/>
			<br/>
		</p>
        <input type="submit" class="btn_noStyle btn_connexion btn_form" value=" Connexion " name="Connexion">
        <input type="reset" class="btn_noStyle btn_deconnexion btn_form" value=" Vider le formulaire ">
		<br/>
		<br/>
        <a id="ins" href="inscription.php">Inscrivez-vous</a>
	</form>


<?php
include('footer.php');
?>