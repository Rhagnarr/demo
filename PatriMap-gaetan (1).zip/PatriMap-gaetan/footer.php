		</section>
		<footer id="wrap_footer">
			<p>© PatriMaps - ENSISA 2018 Projet 1A IR  </p>
			<pre>     </pre>
            <p><a class="foot" href="apropos.php"> À propos</a></p>
		</footer>
	</body>
</html>
