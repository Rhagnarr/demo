<?php
session_start();

try{ // on essaie


$bdd = new PDO('mysql:host=localhost;dbname=PatriMap;charset=utf8', 'root', ''); /*

        on stocke la connexion à la base de données dans une variable $bdd
        la connexion se fait via la fonction PDO qui contient trois paramètres
        le premier paramètre est en trois parties : l'hôte du mysql (localhost si on est en local), le nom de la base de données et son encodage
        le second paramètre est l'identifiant de connexion à la base de données
        le dernier paramètre est le mot de passe de connexion à la base de données (en local il n'y a pas de mot de passe)
        */
}
catch(Exception $e){ // sinon on attrape l'erreur
    die('Erreur : '.$e->getMessage()); // on arrête tous les processus et on affiche le message d'erreur
}

if(isset($_POST['Deconnexion'])){
    unset($_SESSION['login']);
    unset($_SESSION['id']);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8" />
    <title>PatriMaps</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.1/dist/leaflet.css"
          integrity="sha512-Rksm5RenBEKSKFjgI3a41vrjkw4EVPlJ3+OiI65vTjIdo9brlAacEuKOiQ5OFh7cOI1bkDwLqdLw3Zg0cRJAAQ=="
          crossorigin=""/>
    <link rel="stylesheet" href="style.css" />

    <script src="https://unpkg.com/leaflet@1.3.1/dist/leaflet.js"
            integrity="sha512-/Nsx9X4HebavoBvEBuyp3I7od5tA0UzAxs+j83KgC8PU0kgB4XiK4Lfe4y4cgBtaRJQEIFCW+oC506aPT2L1zw=="
            crossorigin=""></script>
</head>
<body>
<?php include "navigation.php" ?>

<section id="content">