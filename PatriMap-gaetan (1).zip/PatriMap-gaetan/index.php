<?php
include('header.php');
$errorMessage = '';
if(isset($_POST['Connexion'])){ // si le bouton Connexion a été cliqué alors
    if(!empty($_POST['mail'])){
        $mail = $_POST['mail'];
        if(!empty($_POST['mot de passe'])){
            $mdp = $_POST['mot_de_passe'];
            $insertion = $bdd->prepare('SELECT Mot_de_passe FROM Utilisateur WHERE Email="'.$mail.'"');
            $insertion->execute(); // exécution de la requête stockée dans la variable $insertion
            $grain = 'b54sFmjJ52';
            $sel = 'a12Gfd51gzR';
            $sha1 = sha1($grain.$mdp.$sel);

            if($sha1==$insertion){
                session_start();
                $insertion = $bdd->prepare('SELECT nom FROM Utilisateur WHERE Email="'.$mail.'"');
                $insertion->execute();
                $_SESSION['login'] = $insertion;
            }
            else {
                $errorMessage = 'Mauvais password !';
            }
        }
	}
}

if (!isset($_SESSION['login'])){
    echo "<div class=\"div_msg div_msg_valid\">
        <p><b>Bienvenue sur PatriMap !</b></p>
        <p>PatriMap est un site innovant qui permet de partager des informations concernant le patrimoine de façon collaborative.</p>
        <p>Veuillez vous connecter, afin de pouvoir identifier des éléments de notre patrimoine et accéder à d'autre options !</p>
    </div>";
}
?>
    <div id="wrap_index">

		<div id="mapid"></div>
        <script>
            var mymap = L.map('mapid').setView([47.729373, 7.310629], 13);
            L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
                attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
                maxZoom: 18,
                id: 'mapbox.streets',
                accessToken: 'pk.eyJ1IjoiZ3BpYWxsYSIsImEiOiJjamlhcWI1ajExYTFxM2tyeHh4MWF1bjRxIn0.xsG8CN5ZyPV4JwYojldaLg'
            }).addTo(mymap);
            <?php
            $reponse = $bdd->query("SELECT * FROM Patrimoine");
            while($row = $reponse->fetch()) {
                ?>
            var marker = L.marker([<?php echo $row['Latitude'] ?>, <?php echo $row['Longitude'] ?>]).addTo(mymap);
            element='<a href="patrimoine.php?id=' + <?php echo "\"".$row['Id']."\""; ?> + '">' + <?php echo "\"".$row['Nom']."\""; ?> + '</a></br>' + <?php $text = $row['Description']; if(strlen($text) > 200){ $text = substr($text, 0, 200)."...";}; echo "\"".$text."\""; ?>;
            marker.bindPopup(element);

            <?php
            }
            ?>

        </script>

    </div>

<?php 
include('footer.php'); 
?>
