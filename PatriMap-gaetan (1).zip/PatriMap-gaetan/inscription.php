<?php
include('header.php');

$redirect = false;

if(isset($_POST['inscription'])){ // si le bouton inscription a été cliqué alors
    $errormessage = '';

    if(empty($_POST['nom'])){// si le champ nom a été rempli alors
        $errormessage .= "<p>Le nom n'a pas été donné !</p>";
    }
    else{
        $nom = $_POST['nom']; // stockage de la valeur du champ nom dans la variable $nom
        if(empty($_POST['prenom'])) {
            $errormessage .= "<p'>Le prénom n'a pas été donné !</p>";
        }
        else {
            $prenom = $_POST['prenom'];
            if(empty($_POST['mail'])) {
                $errormessage .= "<p>Le mail n'a pas été donné !</p>";
            }
            else{
                $mail = $_POST['mail'];
                if(empty($_POST['mdp'])){
                    $errormessage .= "<p>Le mot de passe n'a pas été donné !</p>";
                }else {
                    $mdp = $_POST['mdp'];

                    if(empty($_POST['confmdp'])) {
                        $errormessage .= "<p>Le mot de passe de confirmation n'a pas été donné !</p>";
                    }
                    else {

                        if($mdp != $_POST['confmdp']){
                            $errormessage .= "<p>Les deux mots de passe sont différents !</p>";
                        }
                        else{
                            $nbrRows = $bdd->query('SELECT count(*) AS `count` FROM `Utilisateur` WHERE `Email` = "'.$mail.'"')->fetchColumn();
                            // nbrRows Vérifie que l'@ mail n'est pas déjà utilisée

                            if($nbrRows != "0"){
                                $errormessage .= "<p>Cette adresse mail est déjà utilisée !</p>";
                            } else {
                                // Si @ mail inutilisée

                                $mdp1 = $_POST['confmdp'];
                                $grain = 'b54sFmjJ52';      // Grain
                                $sel = 'a12Gfd51gzR';       // Sel
                                $sha1 = sha1($grain.$mdp.$sel); // Chiffrement SHA1

                                // Requête d'insertion
                                $stmt = $bdd->prepare('INSERT INTO Utilisateur(Nom, Prenom, Email, Password) VALUES(:Nom, :Prenom, :Email, :Password)');
                                $stmt->bindParam(':Nom', $nom);
                                $stmt->bindParam(':Prenom', $prenom);
                                $stmt->bindParam(':Email', $mail);
                                $stmt->bindParam(':Password', $sha1);

                                // exécution de la requête stockée dans la variable $insertion
                                if($stmt->execute())
                                {
                                    $redirect = true;
                                }
                                else {
                                    $errormessage .= "<p>Une erreur est survenue !</p>";
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

if(isset($errormessage)){

    ?>
    <div class="div_msg div_msg_error">
        <p><b>Une ou plusieurs erreurs sont survenues !</b></p>
        <?php echo $errormessage ?>
    </div>
    <?php
}

if($redirect){
    echo "<script type='text/javascript'>document.location.replace('connexion.php');</script>";
}
?>
<h2 class="inscp">Inscription</h2>
</br>
    <form class="formul" method="post" action="inscription.php" >
        <p>
            <label class="Text" for="nom">Nom : </label>
            <input type="text" class="Text" name="nom" placeholder="Votre nom"  />
			<br/>
        </p>
        <p>
            <label class="Text" for="prenom">Prénom : </label>
            <input type="text" class="Text" name="prenom" placeholder="Votre prenom"  />
			<br/>
        </p>
        <p>
            <label class="Text" for="mail">Mail : </label>
            <input type="email" class="Text" name="mail" placeholder="Votre mail"  />
			<br/>
        </p>
        <p>
            <label class="Text" for="mdp">Mot de passe :</label>
            <input type ="password" class="Text" name="mdp" placeholder="Votre mot de passe"/>
			<br/>
		</p>
        <p>
            <label class="Text" for="confmdp">Confirmation Mot de passe :</label>
            <input type ="password" class="Text" name="confmdp" placeholder="Confirmez votre mot de passe"/>
			<br/>
		</p>

        <input type="submit" class="btn_noStyle btn_connexion btn_form" value=" Inscription " name="inscription">
        <input type="reset" class="btn_noStyle btn_deconnexion btn_form" value=" Vider le formulaire ">
    </form>

<?php
include('footer.php');
?>