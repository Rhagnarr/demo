<?php
include('header.php');
if(isset($_POST['ajout'])) // On est en mode "ajout"
{
    if(!empty($_POST['Nom']) && !empty($_POST['Description']) && !empty($_POST['Longitude']) && !empty($_POST['Latitude']))
    {
        $Nom = $_POST['Nom'];
        $Description = $_POST['Description'];
        $Latitude = $_POST['Latitude'];
        $Longitude = $_POST['Longitude'];

        $error_format = False;

        if(!is_numeric($Longitude)) {
            $errormessage .= "Saisir un nombre réel pour la longitude</br>";
            $error_format = True;
        }
        if(!is_numeric($Latitude)) {
            $errormessage .= "Saisir un nombre réel pour la latitude</br>";
            $error_format = True;
        }

        if(!$error_format){
            // Préparation et configuration
            $stmt = $bdd->prepare("INSERT INTO Patrimoine (Nom, Description, Longitude, Latitude) VALUES (:Nom, :Description, :Longitude, :Latitude)");
            // On remplace les paramètres
            $stmt->bindParam(':Nom', $Nom);
            $stmt->bindParam(':Description', $Description);
            $stmt->bindParam(':Longitude', $Longitude);
            $stmt->bindParam(':Latitude', $Latitude);
            $res = $stmt->execute();
            // Execution, on affiche un message suivant le résultat de la requête
            if($res){
                $validmessage .= "Le patrimoine a bien été ajouté !</br>";
            }
            else {
                $errormessage .= "Une erreur est survenue, le patrimoine n'a pas pu être ajouté !</br>";
            }
        }
    }
    else {
        $errormessage .= "Tous les champs doivent être renseignés</br>";
    }
}

if(isset($errormessage)){

    ?>
    <div class="div_msg div_msg_error">
        <p><b>Une ou plusieurs erreurs sont survenues !</b></p>
        <?php echo $errormessage ?>
    </div>
    <?php
}

if(isset($validmessage)){

    ?>
    <div class="div_msg div_msg_valid">
        <?php echo $validmessage ?>
    </div>
    <?php
}

?>
<h2 class="inf" >Ajout d'un patrimoine</h2>
<div class="cart">
	<div class="ajout">
    
    <form method="post" class="form" action="modification.php">
        <h3>Informations</h3>
        <p>
            <label class="Text"   for="Nom">Nom :</label>
            <input type="varchar" class="Text" name="Nom" placeholder="Nom du patrimoine" />
        </p>
        <p>
            <label for="Description" class="Text" >Description :</label>
            <input type="text" class="Text" name="Description" placeholder="Description du patrimoine" />
        </p>
				<br/>
        <p>
        <h3>Coordonnées</h3>
        </p>

        <p>
            <label class="Text" for="Longitude">Longitude :</label>
            <input class="Text" id="lng_input" type="real" name="Longitude" placeholder="Saisir la longitude" />
        </p>

        <p>
            <label class="Text" for="Latitude">Latitude :</label>
            <input class="Text" id="lat_input" type="real" name="Latitude" placeholder="Saisir la latitude" />
			<br/>
		</p>
        <input class="btn_noStyle btn_connexion btn_form" type="submit" value=" Ajouter le patrimoine " name="ajout" />
        <input class="btn_noStyle btn_deconnexion btn_form" type="reset" value=" Vider le formulaire " />
    </form>
	</div>
	<div id="mapid" class="carte"  style="width=65%;height:500px;"></div>

    <script src="scripts/modification_map.js"></script>
</div>
	
	<?php
include('footer.php');
?>