
<header id="wrap_header">

    <div class="header_gauche">
        <a href="index.php">Accueil</a>
	<?php

         if (isset($_SESSION['login'])){
             echo '<a href="profil.php">Mon Profil</a>';
             echo '<a href="modification.php">Ajouter</a>';
         }
         ?>
    </div>

    <div class="logo_header">
        <a href="index.php"><img id="logo_img" src="images/logo.png" alt="Logo"/></a>
    </div>

    <div class="header_droit">
        <form id="form" action="recherche.php" name="search" method="POST" onsubmit="return verif();">
		<input id="search_header" type="text" name="champ" placeholder="Rechercher un patrimoine...">
		</form>
	<script>
function verif(){
	if (document.search.champ.value==""){
	alert("Le champ recherche est vide !");
    return false;
		
	}
	return true;
}
</script>
		
         <?php
         if (!isset($_SESSION['login'])){
             echo '<form method="post" action="connexion.php" >
                    <p>
                        <input class="btn_noStyle btn_connexion" type="submit" value="Connexion" name="">
                    </p>
                </form>';
         }
         else{
            echo '<form method="post" action="index.php" >
                    <p>
                        <input class="btn_noStyle btn_deconnexion" type="submit" value="Déconnexion" name="Deconnexion">
                    </p>
                </form>';
	    }
        ?>
    </div>
</header>
