<?php

include('header.php');

if(isset($_POST['env_note']) && !empty($_POST['Note']) && isset($_SESSION['id'])){
    if(is_numeric($_POST['Note']) && $_POST['Note']<=5 && $_POST['Note']>=0){

        $Note=$_POST['Note'];
        $Id_Patri=$_GET['id'];
        $Id_User=$_SESSION['id'];

        $req2 = $bdd->prepare("INSERT INTO Note (Id_User,Id_Patri,Note) VALUES (:Id_User,:Id_Patri,:Note)");
        $req2->bindParam(':Id_User', $Id_User);
        $req2->bindParam(':Id_Patri', $Id_Patri);
        $req2->bindParam(':Note', $Note);
        $res1 = $req2->execute();

        if($res1){
            echo "<p class='valid'>La note a été ajouté</p>";
        }
        else
        {

            $req5 = $bdd->prepare("UPDATE Note SET Note.Note=$Note WHERE Id_Patri=$Id_Patri AND Id_User='$Id_User'");
            $res2 = $req5->execute();
            if($res2){
                echo "<p class='valid'>La note a été modifiée</p>";
            }
        }
    }
}

if(isset($_POST['env_comm']) && !empty($_POST['Commentaire'])  ){

    if(is_string($_POST['Commentaire'])){
        $Commentaire=$_POST['Commentaire'];
        $Id_Patri=$_GET['id'];
        $Id_User=$_SESSION['id'];

        $stmt = $bdd->prepare("INSERT INTO Commentaire (Id_User, Id_Patri, Commentaire) VALUES (?, ?, ?)");
        $stmt->bindParam(1, $_SESSION['id']);
        $stmt->bindParam(2, $_GET['id']);
        $stmt->bindParam(3, $_POST['Commentaire']);

        $res = $stmt->execute();

        if($res){
            echo "<p class='valid'>Le commentaire a été ajouté</p>";
        }
        else {
            echo "<p class='error'>Une erreur est survenue, le commentaire n'a pas pu être ajoutée !</p>";
        }
    }
}

if(isset($_GET['id']))
{
    $Id = $_GET['id'];

    $reponse = $bdd->query('SELECT * FROM Patrimoine WHERE Id="'.$Id.'"');

    if ($reponse->rowCount() == 1) {
        //Condition d'existance dans la BDD

        $row = $reponse->fetch();
        $Nom = $row['Nom'];
        $Description = $row['Description'];
        $Longitude = $row['Longitude'];
        $Latitude = $row['Latitude'];
        ?>

        <div id="accueilpatr">

        <h2>Page patrimoine</h2>
        <h3><?php echo $Nom;?></a></h3>
        <h3>Description:</a></h3>
        <p><?php echo $Description;?></p>

        <h3>Photo(s) du lieu :</h3>
        <p><img src="images/wallpaper.jpg" width="250px" height="250px" alt="Photo du patrimoine" title="photo 1" /></p>
        <br/>
        <h3>Localisation géographique:</h3>
        <p><?php echo "Longitude: ".$Longitude; ?></p>
        <p><?php echo "Latitude: ".$Latitude; ?></p>
        </br>
        <h3>Carte du lieu:</h3>

        <div id="mapid" style="width=100%;height:600px;"></div>
        <script>
            var mymap = L.map('mapid').setView([<?php echo $Latitude;?>, <?php echo $Longitude;?>], 13);
            L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
                attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
                maxZoom: 18,
                id: 'mapbox.streets',
                accessToken: 'pk.eyJ1IjoiZ3BpYWxsYSIsImEiOiJjamlhcWI1ajExYTFxM2tyeHh4MWF1bjRxIn0.xsG8CN5ZyPV4JwYojldaLg'
            }).addTo(mymap);
            L.marker([<?php echo $row['Latitude'] ?>, <?php echo $row['Longitude'] ?>]).addTo(mymap);
        </script>

        <?php

        $stmt = $bdd->prepare('SELECT u.Nom, u.Prenom, u.Avatar, c.Commentaire FROM Commentaire c JOIN Utilisateur u ON u.Id = c.Id_User WHERE c.Id_Patri=:id');
        $stmt->bindParam('id', $_GET['id']);
        $stmt->execute();


        echo '<h3>Commentaire(s):</h3>';

        echo '<p>'.$stmt->rowCount().'</p>';

        if($stmt->rowCount() == 0) {
            echo '<p>Il n\'y a pas de commentaires </p>';
        }
        else
        {
            while ($row = $stmt->fetch() ) {

                /*$Commentaire = $row['Commentaire'];
                $Nom = $row['Nom'];
                $Prenom = $row['Prenom'];
                $Avatar = $row['Avatar'];*/

                echo '<div class="comment">
                        <img src="' . $row['Avatar'] . '" alt="image_utilisateur"/>
                        <p><b>'.$row['Nom'].'</a></b></p>
                        </p><p>Commentaire : ' . $row['Commentaire'] . '</p>
                      </div>';
            }
        }

        if(isset($_SESSION['id']))
        {
            ?>
            <form method="post" action="patrimoine.php?id=<?php echo $Id; ?>">
                <p>
                    <label for="Commentaire"> Ajoutez un commentaire: </label>
                    <input type="text" name="Commentaire" placeholder="Ecrivez un commentaire..." />
                    <input type="submit" value="Envoyer" name="env_comm" />
                    <input type="reset" value="Annuler" />
                </p>
            </form>
            <?php
        }

        $result = $bdd->query('SELECT * FROM Note WHERE Id_Patri="'.$Id.'"');
        $somme=0;
        $cpt=$result->rowcount();

        while ($donnees = $result->fetch()){
            $somme += $donnees['Note'];
        }

        if($cpt == 0){
            $Note =0;
        }
        else {
            $Note=$somme/$cpt;
        }

        if(!empty($Note)){

            ?>

            <h3>Note : <?php echo round($Note, 1); echo "/5";?></h3>
            <p> <?php echo "Il y a ".$cpt." avi(s)";?></p>

            <?php
        }
        else {
            echo '<h3>Pas de notes pour ce patrimoine </h3>';
        }

        if(isset($_SESSION['id'])){
            ?>

            <form method="post" action="patrimoine.php?id=<?php echo $Id; ?>">
                <p>
                    <label for="Note"> Ajoutez une note: </label>
                    <input type="number" name="Note" placeholder="Note" step="0.1" max="5" min="0">
                    <input type="submit" value="Evaluer" name="env_note" />
                    <input type="reset" value="Annuler" />
                </p>
            </form>
            <p><a href="modification.php?id=<?php echo $id; ?>">Modifier ce patrimoine</a></p>

            </div>

            <?php
        }
    }
    else {
        ?>
        <div class="div_msg div_msg_error">
            <p><b>Erreur</b></p>
            <p>Vous tentez d'acceder à une page qui n'existe pas ! Ouste !</p>
        </div>
        <?php
    }
}
else {
    ?>
    <div class="div_msg div_msg_error">
        <p><b>Erreur</b></p>
        <p>Vous tentez d'acceder à une page qui n'existe pas ! Ouste !</p>
    </div>
    <?php
}

include('footer.php');
?>