
<?php
include ('header.php');

if(!isset($_SESSION['id']))
{
    header('Location: index.php');
    exit();
}

$reqprofil = "SELECT prenom, nom, avatar, email, id FROM Utilisateur WHERE id=:id" ;
$reqprofil = $bdd->prepare($reqprofil);
$reqprofil->execute(array('id'=>$_SESSION['id']));
$data_profil_user = $reqprofil->fetch();

if(isset($_POST['modification'])){

    if(isset($_FILES['icone']) && !empty($_FILES['icone']['tmp_name'])) {

        $path = $_FILES['icone']['tmp_name'];
        $type = pathinfo($path, PATHINFO_EXTENSION);
        $data = file_get_contents($path);
        //$base64 = base64_encode($data);
        $base64 = 'data:' . $type . ';base64,' . base64_encode($data);

        $stmt = $bdd->prepare('UPDATE Utilisateur SET Avatar=:Ava WHERE Id=:Id');
        $stmt->bindParam(':Ava', $base64);
        $stmt->bindParam(':Id', $_SESSION['id']);
        // exécution de la requête stockée dans la variable $insertion
        $stmt->execute();
    }

    if(isset($_POST['nom']) && $_POST['nom'] != $data_profil_user['nom']) {

        if(!empty($_POST['nom'])){

            $stmt = $bdd->prepare('UPDATE Utilisateur SET Nom=:Nom WHERE Id=:Id');
            $stmt->bindParam(':Nom', $_POST['nom']);
            $stmt->bindParam(':Id', $_SESSION['id']);

            $stmt->execute();
        }
        else {
            $errormessage .= "Le nom ne peut pas être vide !</br>";
        }
    }


    if(isset($_POST['prenom']) && $_POST['prenom'] != $data_profil_user['prenom']) {

        if(!empty($_POST['prenom'])){

            $stmt = $bdd->prepare('UPDATE Utilisateur SET Prenom=:Prenom WHERE Id=:Id');
            $stmt->bindParam(':Prenom', $_POST['prenom']);
            $stmt->bindParam(':Id', $_SESSION['id']);

            $stmt->execute();
        }
        else{
            $errormessage .= "Le prenom ne peut pas être vide !</br>";
        }
    }
}

if(isset($errormessage)){

    ?>
    <div class="div_msg div_msg_error">
        <p><b>Une ou plusieurs erreurs sont survenues !</b></p>
        <?php echo $errormessage ?>
    </div>
    <?php
}

$reqprofil = "SELECT prenom, nom, avatar, email, id FROM Utilisateur WHERE id=:id" ;
$reqprofil = $bdd->prepare($reqprofil);
$reqprofil->execute(array('id'=>$_SESSION['id']));
$data_profil_user = $reqprofil->fetch();

$sql = "SELECT c.Id_Patri, c.Commentaire, p.Nom FROM Commentaire c JOIN Patrimoine p ON p.Id = c.Id_Patri WHERE c.id_user=:id ORDER BY c.Id DESC LIMIT 5";
$data_comment = $bdd->prepare($sql);
$data_comment->bindParam(":id", $_SESSION['id']);
$data_comment->execute();

$sql='SELECT n.Id_Patri, p.Nom, n.Note FROM Note n JOIN Patrimoine p On p.Id = n.Id_Patri WHERE n.Id_User = :id LIMIT 5';
$data_note=$bdd->prepare($sql);
$data_note->bindParam(":id", $_SESSION['id']);
$data_note->execute();

$sql='SELECT count(*) FROM Note WHERE Id_User = :id';
$data_nbrNotes=$bdd->prepare($sql);
$data_nbrNotes->bindParam(":id", $_SESSION['id']);
$data_nbrNotes->execute();
$nbrNotes = $data_nbrNotes->fetchColumn();

$sql='SELECT count(*) FROM Commentaire WHERE Id_User = :id';
$data_nbrComm=$bdd->prepare($sql);
$data_nbrComm->bindParam(":id", $_SESSION['id']);
$data_nbrComm->execute();
$nbrComm = $data_nbrComm->fetchColumn();

$sql='SELECT count(*) FROM Note';
$data_nbrNotes=$bdd->prepare($sql);
$data_nbrNotes->execute();
$nbrNotesTot = $data_nbrNotes->fetchColumn();

$sql='SELECT count(*) FROM Commentaire';
$data_nbrCommTot=$bdd->prepare($sql);
$data_nbrCommTot->execute();
$nbrCommTot = $data_nbrCommTot->fetchColumn();

$sql='SELECT count(*) FROM Patrimoine';
$data_nbrPat=$bdd->prepare($sql);
$data_nbrPat->execute();
$nbrPat = $data_nbrPat->fetchColumn();
?>

<div id="profil_wrap">
    <div id="profil_gauche" class="profil">
        <h2>Informations personnelles</h2>
        <form method="post" action="profil.php" enctype="multipart/form-data">
            <p class="Text">Avatar :</p>
            <img id="img_profil" src="<?php echo $data_profil_user['avatar']; ?>" alt="image_utilisateur"/>
            <p>
                <input type="file" name="icone" id="icone" accept="image/*"/>
            </p>
            <p>
                <label class="Text" for="nom">Nom : </label>
                <input type="text" class="Text" name="nom" placeholder="Votre nom" value="<?php echo $data_profil_user['nom']; ?>" />
            </p>
            <p>
                <label class="Text" for="prenom">Prénom : </label>
                <input type="text" class="Text" name="prenom" placeholder="Votre prenom" value="<?php echo $data_profil_user['prenom']; ?>"/>
            </p>

            <input type="submit" class="btn_noStyle btn_modifier btn_form" value=" Modifier les infos " name="modification">
        </form>

    </div>
    <div id="profil_centre" class="profil">
        <div id="profil_centre_conteneur">
            <h2>Vos dernières notes</h2>
            <?php
            if($data_note->rowCount() == 0)
            {
                echo '<p>Vous n\'avez encore donné de note sur un patrimoine</p>';
            }
            else
            {
                while ($row = $data_note->fetch()){
                    echo '<div class="comment">
                        <img src="'. $data_profil_user['avatar'].'" alt="image_utilisateur"/>
                        <p><b><a href="patrimoine.php?id='.$row['Id_Patri'].'">'.$row['Nom'].'</a></b></p>
                        </p><p>Note : '.$row['Note'].' / 5</p>
                      </div>';
                }
            }
            ?>
            <h2>Vos derniers commentaires</h2>
            <?php
            if($data_comment->rowCount() == 0)
            {
                echo '<p>Vous n\'avez encore posté de commentaire !</p>';
            }
            else {
                while ($row = $data_comment->fetch()) {
                    echo '<div class="comment">
                        <img src="' . $data_profil_user['avatar'] . '" alt="image_utilisateur"/>
                        <p><b><a href="patrimoine.php?id=' . $row['Id_Patri'] . '">' . $row['Nom'] . '</a></b></p>
                        </p><p>Commentaire : ' . $row['Commentaire'] . '</p>
                      </div>';
                }
            }
            ?>
        </div>

    </div>

    <div id="profil_droit" class="profil">
        <h2>Vos statistiques</h2>

        <p>Nombre de commentaires : <?php echo $nbrComm; ?></p>
        <p>Nombre de notes : <?php echo $nbrNotes; ?></p>

        <h2>Statistiques totales</h2>

        <p>Nombre de commentaires : <?php echo $nbrCommTot; ?></p>
        <p>Nombre de notes : <?php echo $nbrNotesTot; ?></p>
        <p>Nombre de patrimoines : <?php echo $nbrPat; ?></p>
    </div>


</div>

<?php include("footer.php"); ?>
	