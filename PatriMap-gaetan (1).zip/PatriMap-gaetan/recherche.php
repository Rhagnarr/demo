<?php include('header.php');
if (isset($_POST['champ'])){

    echo "<p>Recherche effectuée : '".$_POST['champ']."'</p>";

    //$req_search='select nom, description, photo, p.id from Patrimoine p inner join Photos ph on p.id = ph.id_patri where nom like "'.$_POST["champ"].'%"';
    $req_search='SELECT * FROM Patrimoine p WHERE p.Nom LIKE "%'.$_POST["champ"].'%"';
    $req_search=$bdd->query($req_search);

    //$req_search2='select nom, description, photo, p.id from Patrimoine p inner join Photos on p.id = ph.id_patri where description like "%'.$_POST['champ'].'%"';
    $req_search2='SELECT * FROM Patrimoine p WHERE Description LIKE "%'.$_POST["champ"].'%"';
    $req_search2=$bdd->query($req_search2);

    if($data_search=$req_search->fetch())
    {
        $list_id[]=$data_search['Id'];
        echo '<h2>Liste des Patrimoines Trouvés ( '.$req_search->rowCount().' résultat(s))</h2>';

        do{
            $list_id[]=$data_search['Id'];
            /*echo '<a href="patrimoine.php?id='.$data_search['id'].'"><img class="search_img" src="'.$data_search['photo'].'" /></a>';*/
		    echo '<a href="patrimoine.php?id='.$data_search['Id'].'">'.$data_search['Nom'].'</a><br/>';

        }while($data_search=$req_search->fetch());
    }

    else{
        echo '<p>Oops... Nous ne trouvons pas votre patrimoine.</p>';

    }

    if($data_search2=$req_search2->fetch()){
        $i=0;
        echo '<h2>Résultats en rapport à votre recherche ( '.$req_search2->rowCount().' résultat(s))</h2>';
        do{
            if($data_search2['Id']!=$list_id[$i]){
                //echo'<a href="patrimoine.php?id='.$data_search2['id'].'"><img class="search_img" src="'.$data_search2['photo'].'" /></a>';
		        echo '<a href="patrimoine.php?id='.$data_search2['Id'].'">'.$data_search2['Nom'].'</a><br/>';
		        echo '<p>'.$data_search2['Description'].'</p>';
            }
            $i++;
        }
        while($data_search2=$req_search2->fetch());
    }
}
else {
    echo '<p>Oops... Nous ne trouvons pas votre patrimoine.</p>';
    ?>
    <script>
        alert("Le champ recherche est vide !");
    </script>
    <?php
}
include('footer.php');
?>

